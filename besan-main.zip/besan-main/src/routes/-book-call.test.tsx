import { act, cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const { availability, submitBooking } = vi.hoisted(() => ({
  availability: {
    openDates: ["2026-07-19"],
    slots: [{ startsAt: "11:00", endsAt: "12:00" }],
    monthLoading: false,
    slotsLoading: false,
    error: "",
    loadMonth: vi.fn().mockResolvedValue(undefined),
    loadDate: vi.fn().mockResolvedValue(undefined),
  },
  submitBooking: vi.fn(),
}));

vi.mock("@/components/site-shell", () => ({ SiteFooter: () => null, SiteNav: () => null }));
vi.mock("gsap", () => ({ default: { context: vi.fn() } }));
vi.mock("@/features/book-call/booking.functions", () => ({ submitBooking }));
vi.mock("@/features/book-call/use-booking-availability", () => ({
  useBookingAvailability: () => availability,
}));

Object.defineProperty(window, "matchMedia", {
  writable: true,
  value: vi.fn().mockReturnValue({ matches: true }),
});

import { BookCallPage } from "./book-call";

function selectJulyNineteenth() {
  fireEvent.click(screen.getByRole("button", { name: /sunday, july 19th, 2026/i }));
}

function selectJulyTwentieth() {
  fireEvent.click(screen.getByRole("button", { name: /monday, july 20th, 2026/i }));
}

function fillBookingForm() {
  selectJulyNineteenth();
  fireEvent.click(screen.getAllByRole("button", { name: "11:00" })[0]);
  fireEvent.change(screen.getByLabelText("Full Name"), { target: { value: "Noor Al-Hashemi" } });
  fireEvent.change(screen.getByLabelText("WhatsApp Number"), {
    target: { value: "+970591234567" },
  });
}

function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>((resolvePromise) => {
    resolve = resolvePromise;
  });
  return { promise, resolve };
}

describe("book-call route", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-07-15T12:00:00"));
    vi.clearAllMocks();
    vi.spyOn(window, "scrollTo").mockImplementation(() => undefined);
    availability.openDates = ["2026-07-19"];
    availability.slots = [{ startsAt: "11:00", endsAt: "12:00" }];
    availability.monthLoading = false;
    availability.slotsLoading = false;
    availability.error = "";
  });

  afterEach(() => {
    cleanup();
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  it("shows only persisted date slots after selecting an open date", () => {
    render(<BookCallPage locale="en" />);

    selectJulyNineteenth();

    expect(availability.loadDate).toHaveBeenCalledWith("2026-07-19");
    expect(screen.getAllByRole("button", { name: "11:00" })).toHaveLength(2);
    expect(screen.queryByRole("button", { name: "12:30" })).toBeNull();
  });

  it("uses the Gregorian calendar for Arabic selected-date labels", () => {
    const nativeDateTimeFormat = Intl.DateTimeFormat;
    const formatter = vi.spyOn(Intl, "DateTimeFormat").mockImplementation(function (
      locale,
      options,
    ) {
      expect(locale).toBe("ar-SA-u-ca-gregory");
      return new nativeDateTimeFormat(locale, options);
    } as typeof Intl.DateTimeFormat);
    try {
      render(<BookCallPage locale="ar" />);
      expect(screen.getByTestId("public-site").getAttribute("lang")).toBe("ar");
      const day = document.querySelector('[data-day="2026-07-19"] button')!;
      fireEvent.click(day);

      expect(formatter).toHaveBeenCalledOnce();
    } finally {
      formatter.mockRestore();
    }
  });

  it("keeps the Arabic booking title on one line", () => {
    render(<BookCallPage locale="ar" />);

    const title = screen.getByRole("heading", { level: 1 });
    expect(title.textContent).toBe("احجزي موعدك");
    expect(title.querySelector("br")).toBeNull();
  });

  it("keeps the booking description close to the title", () => {
    render(<BookCallPage locale="ar" />);

    const description = document.querySelector(
      'p[data-book-copy][class*="mt-"]',
    )!;
    expect(description.className).toContain("mt-4");
  });

  it("shows a retry action and hides time choices when availability cannot load", () => {
    availability.error = "Could not load available appointments.";
    render(<BookCallPage locale="en" />);

    expect(screen.getAllByRole("button", { name: "Try again" })).toHaveLength(2);
    expect(screen.queryByRole("button", { name: "11:00" })).toBeNull();
  });

  it("replaces the booking form with a clickable location confirmation after a successful booking", async () => {
    submitBooking.mockResolvedValue({ success: true, appointmentId: "appointment-1" });
    render(<BookCallPage locale="en" />);

    fillBookingForm();
    await act(async () => {
      fireEvent.click(screen.getByRole("button", { name: "Confirm Booking" }));
      await Promise.resolve();
    });

    expect(screen.getByText("Your booking is confirmed")).toBeTruthy();
    expect(screen.getByText(/sunday, july 19, 2026.*11:00/i)).toBeTruthy();
    expect(screen.queryByRole("button", { name: "Confirm Booking" })).toBeNull();
    expect(screen.getByTitle("Atelier location").getAttribute("src")).toContain(
      "32.866546630859375%2C35.29303741455078",
    );
    expect(
      screen
        .getByRole("link", { name: "Open atelier location in Google Maps" })
        .getAttribute("href"),
    ).toBe("https://www.google.com/maps?q=32.866546630859375,35.29303741455078&z=17&hl=ar");
  });

  it("returns to the top of the confirmation after a successful booking", async () => {
    submitBooking.mockResolvedValue({ success: true, appointmentId: "appointment-1" });
    render(<BookCallPage locale="en" />);

    fillBookingForm();
    await act(async () => {
      fireEvent.click(screen.getByRole("button", { name: "Confirm Booking" }));
      await Promise.resolve();
    });

    expect(window.scrollTo).toHaveBeenCalledWith({ top: 0, behavior: "auto" });
  });

  it("shows the punctuality policy in the Arabic booking confirmation", async () => {
    submitBooking.mockResolvedValue({ success: true, appointmentId: "appointment-1" });
    render(<BookCallPage locale="ar" />);

    fireEvent.click(document.querySelector('[data-day="2026-07-19"] button')!);
    fireEvent.click(screen.getAllByRole("button", { name: "11:00" })[0]);
    fireEvent.change(screen.getByLabelText("الاسم الكامل"), { target: { value: "نور" } });
    fireEvent.change(screen.getByLabelText("رقم واتساب"), {
      target: { value: "+970591234567" },
    });
    await act(async () => {
      fireEvent.click(screen.getByRole("button", { name: "تأكيد الحجز" }));
      await Promise.resolve();
    });

    expect(
      screen.getByText(
        "يرجى الالتزام بموعد الحجز. في حال التأخر أكثر من 15 دقيقة، يُعتبر الحجز ملغيًا.",
      ),
    ).toBeTruthy();
  });

  it("keeps the booking form visible when the booking is not saved", async () => {
    submitBooking.mockResolvedValue({ success: false, reason: "storage-error" });
    render(<BookCallPage locale="en" />);

    fillBookingForm();
    await act(async () => {
      fireEvent.click(screen.getByRole("button", { name: "Confirm Booking" }));
      await Promise.resolve();
    });

    expect(screen.getByRole("button", { name: "Confirm Booking" })).toBeTruthy();
    expect(screen.queryByText("Your booking is confirmed")).toBeNull();
    expect(screen.queryByTitle("Atelier location")).toBeNull();
    expect(screen.getByRole("alert").textContent).toContain("We could not save your booking");
  });

  it("refreshes and clears a stale slot without losing customer details", async () => {
    submitBooking.mockResolvedValue({ success: false, reason: "slot-unavailable" });
    render(<BookCallPage locale="en" />);

    selectJulyNineteenth();
    fireEvent.click(screen.getAllByRole("button", { name: "11:00" })[0]);
    fireEvent.change(screen.getByLabelText("Full Name"), { target: { value: "Noor Al-Hashemi" } });
    fireEvent.change(screen.getByLabelText("WhatsApp Number"), {
      target: { value: "+970591234567" },
    });
    await act(async () => {
      fireEvent.click(screen.getByRole("button", { name: "Confirm Booking" }));
      await Promise.resolve();
    });

    expect(screen.getByRole("alert").textContent).toContain(
      "That time is no longer available. Please choose another time.",
    );
    expect(availability.loadDate).toHaveBeenCalledTimes(2);
    expect((screen.getByLabelText("Full Name") as HTMLInputElement).value).toBe("Noor Al-Hashemi");
    expect((screen.getByLabelText("WhatsApp Number") as HTMLInputElement).value).toBe(
      "+970591234567",
    );
    expect(screen.getAllByRole("button", { name: "11:00" })[0].className).not.toContain(
      "bg-foreground",
    );
  });

  it("prevents changing the selected calendar date while booking submission is pending", async () => {
    const pendingSubmission = deferred<{ success: false; reason: "slot-unavailable" }>();
    submitBooking.mockImplementationOnce(() => pendingSubmission.promise);
    availability.openDates = ["2026-07-19", "2026-07-20"];
    render(<BookCallPage locale="en" />);

    selectJulyNineteenth();
    fireEvent.click(screen.getAllByRole("button", { name: "11:00" })[0]);
    fireEvent.change(screen.getByLabelText("Full Name"), { target: { value: "Noor Al-Hashemi" } });
    fireEvent.change(screen.getByLabelText("WhatsApp Number"), {
      target: { value: "+970591234567" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Confirm Booking" }));

    selectJulyTwentieth();

    expect(availability.loadDate).toHaveBeenCalledTimes(1);
    expect(screen.getByText(/sunday, july 19, 2026/i)).toBeTruthy();

    await act(async () => {
      pendingSubmission.resolve({ success: false, reason: "slot-unavailable" });
      await Promise.resolve();
    });
  });

  it("keeps the displayed month and availability loader unchanged while booking submission is pending", async () => {
    const pendingSubmission = deferred<{ success: false; reason: "slot-unavailable" }>();
    submitBooking.mockImplementationOnce(() => pendingSubmission.promise);
    render(<BookCallPage locale="en" />);

    selectJulyNineteenth();
    fireEvent.click(screen.getAllByRole("button", { name: "11:00" })[0]);
    fireEvent.change(screen.getByLabelText("Full Name"), { target: { value: "Noor Al-Hashemi" } });
    fireEvent.change(screen.getByLabelText("WhatsApp Number"), {
      target: { value: "+970591234567" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Confirm Booking" }));

    fireEvent.click(screen.getByRole("button", { name: /go to the next month/i }));

    expect(screen.getByRole("button", { name: /sunday, july 19th, 2026/i })).toBeTruthy();
    expect(availability.loadMonth).toHaveBeenCalledTimes(1);

    await act(async () => {
      pendingSubmission.resolve({ success: false, reason: "slot-unavailable" });
      await Promise.resolve();
    });
  });
});
